LOCAL SETUP (Windows)
1. Open PowerShell in this folder.
2. Run: py -m pip install -r requirements.txt
3. Run: py app.py
4. Open http://127.0.0.1:5000 in your browser.
5. Paste your Gemini API key and meeting notes, then click Extract Action Items.
Keep the PowerShell window open while using the app. Press Ctrl+C to stop it.
This app is for local testing. Do not expose it publicly or share your API key.
